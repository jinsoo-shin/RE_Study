package Baekjoon_N;

import java.io.*;
import java.util.*;

public class Main_default {

	public static void main(String[] args) throws IOException {
		String src = "1 1 1";
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		br = new BufferedReader(new StringReader(src));
		StringTokenizer sb = new StringTokenizer(br.readLine());

	}

}
