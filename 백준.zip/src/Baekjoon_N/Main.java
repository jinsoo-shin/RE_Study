package Baekjoon_N;

import java.io.*;
import java.util.*;
public class Main {

	public static void main(String[] args) throws IOException {
		System.setIn(new FileInputStream("src/Baekjoon_N/input.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	}

}
